using Avalonia.Controls;

namespace Lab22.UserListDataGrid;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
