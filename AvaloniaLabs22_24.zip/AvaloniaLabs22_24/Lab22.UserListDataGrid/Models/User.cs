using CommunityToolkit.Mvvm.ComponentModel;

namespace Lab22.UserListDataGrid.Models;

public class User : ObservableObject
{
    private string _login = string.Empty;
    private string _password = string.Empty;

    public string Login
    {
        get => _login;
        set => SetProperty(ref _login, value);
    }

    public string Password
    {
        get => _password;
        set => SetProperty(ref _password, value);
    }

    public User() { }

    public User(string login, string password)
    {
        Login = login;
        Password = password;
    }
}
