using System.Collections.ObjectModel;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Lab22.UserListDataGrid.Models;

namespace Lab22.UserListDataGrid.ViewModels;

public class UserListViewModel : ViewModelBase
{
    private string _newLogin = string.Empty;
    private string _newPassword = string.Empty;

    public ObservableCollection<User> Users { get; } = new()
    {
        new User("admin", "12345"),
        new User("student", "qwerty"),
        new User("teacher", "avalonia"),
        new User("guest", "guest")
    };

    public string NewLogin
    {
        get => _newLogin;
        set => SetProperty(ref _newLogin, value);
    }

    public string NewPassword
    {
        get => _newPassword;
        set => SetProperty(ref _newPassword, value);
    }

    public ICommand AddCommand { get; }
    public ICommand DeleteCommand { get; }

    public UserListViewModel()
    {
        AddCommand = new RelayCommand(AddUser);
        DeleteCommand = new RelayCommand<User?>(DeleteUser);
    }

    private void AddUser()
    {
        if (string.IsNullOrWhiteSpace(NewLogin) || string.IsNullOrWhiteSpace(NewPassword))
            return;

        Users.Add(new User(NewLogin.Trim(), NewPassword));
        NewLogin = string.Empty;
        NewPassword = string.Empty;
    }

    private void DeleteUser(User? user)
    {
        if (user is null)
            return;

        Users.Remove(user);
    }
}
