using CommunityToolkit.Mvvm.ComponentModel;

namespace Lab22.UserListDataGrid.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
