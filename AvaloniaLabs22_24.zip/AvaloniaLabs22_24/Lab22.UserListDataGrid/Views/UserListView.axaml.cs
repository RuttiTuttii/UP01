using Avalonia.Controls;

namespace Lab22.UserListDataGrid.Views;

public partial class UserListView : UserControl
{
    public UserListView()
    {
        InitializeComponent();
    }
}
