using System;
using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Lab23.ConfigurationDI.Services;
using Lab23.ConfigurationDI.ViewModels;

namespace Lab23.ConfigurationDI;

public partial class App : Application
{
    public static IConfiguration Configuration { get; private set; } = null!;
    public static ServiceProvider Services { get; private set; } = null!;

    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        ConfigurationBuilder builder = new ConfigurationBuilder();
        builder.SetBasePath(AppContext.BaseDirectory);
        builder.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
        Configuration = builder.Build();

        var collection = new ServiceCollection();
        collection.AddSingleton<NavigationService>();
        collection.AddSingleton<MainViewModel>();
        collection.AddTransient<RegistrationViewModel>();
        collection.AddTransient<AuthorizationViewModel>();
        Services = collection.BuildServiceProvider();

        var navigation = Services.GetRequiredService<NavigationService>();
        navigation.NavigateTo<RegistrationViewModel>();

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            desktop.MainWindow = new MainWindow
            {
                DataContext = Services.GetRequiredService<MainViewModel>()
            };
        }

        base.OnFrameworkInitializationCompleted();
    }
}
