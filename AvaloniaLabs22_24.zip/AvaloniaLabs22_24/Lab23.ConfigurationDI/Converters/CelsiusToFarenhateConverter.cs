using System;
using System.Globalization;
using Avalonia.Data.Converters;

namespace Lab23.ConfigurationDI.Converters;

public class CelsiusToFarenhateConverter : IValueConverter
{
    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is null)
            return null;

        if (!double.TryParse(value.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out double celsius))
            return value;

        return celsius * 9 / 5 + 32;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is null)
            return 0d;

        string text = value.ToString() ?? "0";
        text = text.Replace(',', '.');

        if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out double fahrenheit))
            return 0d;

        return (fahrenheit - 32) * 5 / 9;
    }
}
