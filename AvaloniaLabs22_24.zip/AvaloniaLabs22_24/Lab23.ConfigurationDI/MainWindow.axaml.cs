using Avalonia.Controls;

namespace Lab23.ConfigurationDI;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
