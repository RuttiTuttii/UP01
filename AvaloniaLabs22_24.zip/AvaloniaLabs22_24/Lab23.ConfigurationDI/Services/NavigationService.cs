using System;
using System.Collections.Generic;
using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.Extensions.DependencyInjection;
using Lab23.ConfigurationDI.ViewModels;

namespace Lab23.ConfigurationDI.Services;

public class NavigationService : ObservableObject
{
    private readonly Stack<ViewModelBase> _navigationStack = new();

    public ViewModelBase Current => _navigationStack.Peek();

    public bool CanGoBack => _navigationStack.Count > 1;

    public void NavigateTo<T>(Action<T>? action = null) where T : ViewModelBase
    {
        var viewModel = App.Services.GetRequiredService<T>();
        NavigateTo(viewModel, action);
    }

    public void NavigateTo<T>(T viewModel, Action<T>? action = null) where T : ViewModelBase
    {
        action?.Invoke(viewModel);
        _navigationStack.Push(viewModel);
        OnPropertyChanged(nameof(Current));
        OnPropertyChanged(nameof(CanGoBack));
    }

    public void GoBack()
    {
        if (_navigationStack.Count <= 1)
            return;

        _navigationStack.Pop();
        OnPropertyChanged(nameof(Current));
        OnPropertyChanged(nameof(CanGoBack));
    }
}
