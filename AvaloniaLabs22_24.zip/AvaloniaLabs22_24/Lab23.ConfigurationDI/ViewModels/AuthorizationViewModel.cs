using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Lab23.ConfigurationDI.Services;

namespace Lab23.ConfigurationDI.ViewModels;

public class AuthorizationViewModel : ViewModelBase
{
    private readonly NavigationService _navigation;
    private string _login = string.Empty;
    private string _apiKeyFromRegistration = string.Empty;

    public string Login
    {
        get => _login;
        set => SetProperty(ref _login, value);
    }

    public string ApiKeyFromRegistration
    {
        get => _apiKeyFromRegistration;
        set => SetProperty(ref _apiKeyFromRegistration, value);
    }

    public ICommand GoBackCommand { get; }
    public ICommand GoToRegistrationCommand { get; }

    public AuthorizationViewModel(NavigationService navigation)
    {
        _navigation = navigation;
        GoBackCommand = new RelayCommand(_navigation.GoBack);
        GoToRegistrationCommand = new RelayCommand(GoToRegistration);
    }

    private void GoToRegistration()
    {
        _navigation.NavigateTo<RegistrationViewModel>(x => x.Login = Login);
    }
}
