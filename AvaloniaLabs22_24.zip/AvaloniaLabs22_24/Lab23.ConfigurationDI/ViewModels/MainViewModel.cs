using System.ComponentModel;
using Lab23.ConfigurationDI.Services;

namespace Lab23.ConfigurationDI.ViewModels;

public class MainViewModel : ViewModelBase
{
    private readonly NavigationService _navigation;

    public ViewModelBase CurrentPage => _navigation.Current;

    public MainViewModel(NavigationService navigation)
    {
        _navigation = navigation;
        _navigation.PropertyChanged += navigation_PropertyChanged;
    }

    private void navigation_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(NavigationService.Current))
            OnPropertyChanged(nameof(CurrentPage));
    }
}
