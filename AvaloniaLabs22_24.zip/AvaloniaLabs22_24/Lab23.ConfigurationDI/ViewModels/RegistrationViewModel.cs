using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Lab23.ConfigurationDI.Services;

namespace Lab23.ConfigurationDI.ViewModels;

public class RegistrationViewModel : ViewModelBase
{
    private readonly NavigationService _navigation;
    private string _login = string.Empty;
    private string _password = string.Empty;
    private double _celsius = 25;

    public string ConfigValue { get; } = App.Configuration.GetSection("ApiKeys")["SomeApi"] ?? "значение не найдено";

    public string Login
    {
        get => _login;
        set => SetProperty(ref _login, value);
    }

    public string Password
    {
        get => _password;
        set => SetProperty(ref _password, value);
    }

    public double Celsius
    {
        get => _celsius;
        set => SetProperty(ref _celsius, value);
    }

    public ICommand GoToAuthorizationCommand { get; }

    public RegistrationViewModel(NavigationService navigation)
    {
        _navigation = navigation;
        GoToAuthorizationCommand = new RelayCommand(GoToAuthorization);
    }

    private void GoToAuthorization()
    {
        _navigation.NavigateTo<AuthorizationViewModel>(x =>
        {
            x.Login = Login;
            x.ApiKeyFromRegistration = ConfigValue;
        });
    }
}
