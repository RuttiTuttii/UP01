using CommunityToolkit.Mvvm.ComponentModel;

namespace Lab23.ConfigurationDI.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
