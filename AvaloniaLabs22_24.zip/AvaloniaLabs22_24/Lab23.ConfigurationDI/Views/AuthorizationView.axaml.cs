using Avalonia.Controls;

namespace Lab23.ConfigurationDI.Views;

public partial class AuthorizationView : UserControl
{
    public AuthorizationView()
    {
        InitializeComponent();
    }
}
