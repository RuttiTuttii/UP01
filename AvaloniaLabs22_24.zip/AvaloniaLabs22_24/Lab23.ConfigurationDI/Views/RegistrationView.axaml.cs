using Avalonia.Controls;

namespace Lab23.ConfigurationDI.Views;

public partial class RegistrationView : UserControl
{
    public RegistrationView()
    {
        InitializeComponent();
    }
}
