using Avalonia.Controls;

namespace Lab24.MaterialAvalonia;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
