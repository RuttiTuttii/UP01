using Avalonia.Controls;

namespace Lab24.StylesAvalonia;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
