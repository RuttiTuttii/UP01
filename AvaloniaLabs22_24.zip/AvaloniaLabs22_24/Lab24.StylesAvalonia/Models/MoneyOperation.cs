namespace Lab24.StylesAvalonia.Models;

public class MoneyOperation
{
    public string Description { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public bool IsIncome { get; set; }

    public MoneyOperation() { }

    public MoneyOperation(string description, decimal amount, bool isIncome)
    {
        Description = description;
        Amount = amount;
        IsIncome = isIncome;
    }
}
