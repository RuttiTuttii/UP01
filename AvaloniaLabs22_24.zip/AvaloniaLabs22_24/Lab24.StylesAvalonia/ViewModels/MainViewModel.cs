using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using Lab24.StylesAvalonia.Models;

namespace Lab24.StylesAvalonia.ViewModels;

public class MainViewModel : ObservableObject
{
    public ObservableCollection<string> DemoItems { get; } = new()
    {
        "Первый элемент",
        "Второй элемент",
        "Третий элемент",
        "Четвёртый элемент",
        "Пятый элемент"
    };

    public ObservableCollection<MoneyOperation> Operations { get; } = new()
    {
        new MoneyOperation("Зарплата", 90000, true),
        new MoneyOperation("Продукты", -6500, false),
        new MoneyOperation("Фриланс", 18000, true),
        new MoneyOperation("Интернет", -900, false)
    };
}
