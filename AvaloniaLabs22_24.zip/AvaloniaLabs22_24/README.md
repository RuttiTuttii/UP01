# Avalonia UI — практические работы №22–24

В архиве одно решение `AvaloniaLabs22_24.sln` и четыре проекта:

1. `Lab22.UserListDataGrid` — ПР №22: `ListBox`, `DataGrid`, добавление и удаление пользователей.
2. `Lab23.ConfigurationDI` — ПР №23: `IConfiguration`, DI, навигационный сервис, передача данных, конвертер Celsius/Fahrenheit.
3. `Lab24.StylesAvalonia` — ПР №24, пункты 5.1–5.5: стили, селекторы, псевдоклассы, привязка классов, стили по значениям.
4. `Lab24.MaterialAvalonia` — ПР №24, пункт 5.6: Material.Avalonia и Outlined `TextBox`/`ComboBox`.

## Как открыть

```bash
cd AvaloniaLabs22_24
dotnet restore AvaloniaLabs22_24.sln
```

Запуск нужной практической:

```bash
dotnet run --project Lab22.UserListDataGrid/Lab22.UserListDataGrid.csproj
dotnet run --project Lab23.ConfigurationDI/Lab23.ConfigurationDI.csproj
dotnet run --project Lab24.StylesAvalonia/Lab24.StylesAvalonia.csproj
dotnet run --project Lab24.MaterialAvalonia/Lab24.MaterialAvalonia.csproj
```

Проекты рассчитаны на .NET 8 и Avalonia 11.3.9. Каждый проект содержит файл `README_Report.md` с целью, ответами на контрольные вопросы и выводом.
