using HelloApp.ViewModels;
using System;
using System.Collections.Generic;

namespace HelloApp.Services;

public class NavigationService
{
    private readonly Stack<ViewModelBase> _navigationStack = new();

    public event Action<ViewModelBase>? CurrentPageChanged;

    public ViewModelBase? CurrentPage => _navigationStack.TryPeek(out var page) ? page : null;

    public bool CanGoBack => _navigationStack.Count > 1;

    public void NavigateTo<T>(T viewModel, Action<T>? action = null)
        where T : ViewModelBase
    {
        action?.Invoke(viewModel);
        _navigationStack.Push(viewModel);
        CurrentPageChanged?.Invoke(viewModel);
    }

    public void GoBack(int steps = 1)
    {
        if (_navigationStack.Count == 0)
        {
            return;
        }

        for (var i = 0; i < steps && _navigationStack.Count > 1; i++)
        {
            _navigationStack.Pop();
        }

        CurrentPageChanged?.Invoke(_navigationStack.Peek());
    }
}
