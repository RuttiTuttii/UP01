using Avalonia.Controls;
using Avalonia.Controls.Templates;
using HelloApp.ViewModels;
using System;
using System.Reflection;

namespace HelloApp;

public class ViewLocator : IDataTemplate
{
    public bool SupportsRecycling => false;

    public Control Build(object? data)
    {
        if (data is null)
        {
            return new TextBlock { Text = "No data context" };
        }

        var name = data.GetType().FullName?.Replace("ViewModel", "View");
        var type = name is null ? null : Assembly.GetExecutingAssembly().GetType(name);

        if (type is not null && Activator.CreateInstance(type) is Control control)
        {
            control.DataContext = data;
            return control;
        }

        return new TextBlock { Text = "Not Found: " + name };
    }

    public bool Match(object? data)
    {
        return data is ViewModelBase;
    }
}
