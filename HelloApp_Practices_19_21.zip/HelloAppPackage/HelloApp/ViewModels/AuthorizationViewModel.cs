using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace HelloApp.ViewModels;

public partial class AuthorizationViewModel : ViewModelBase
{
    [ObservableProperty]
    private string login = string.Empty;

    [ObservableProperty]
    private string password = string.Empty;

    [ObservableProperty]
    private string message = "Введите логин и пароль.";

    [RelayCommand]
    private void LoginUser()
    {
        Message = string.IsNullOrWhiteSpace(Login) || string.IsNullOrWhiteSpace(Password)
            ? "Логин и пароль должны быть заполнены."
            : $"Пользователь {Login} авторизован условно.";
    }
}
