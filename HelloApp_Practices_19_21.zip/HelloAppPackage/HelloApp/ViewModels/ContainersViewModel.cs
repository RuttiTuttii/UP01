namespace HelloApp.ViewModels;

public class ContainersViewModel : ViewModelBase
{
}
