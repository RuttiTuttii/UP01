using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.ObjectModel;

namespace HelloApp.ViewModels;

public partial class ControlsViewModel : ViewModelBase
{
    [ObservableProperty]
    private string login = string.Empty;

    [ObservableProperty]
    private string password = string.Empty;

    [ObservableProperty]
    private string email = string.Empty;

    [ObservableProperty]
    private string code = string.Empty;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(Age))]
    private DateTimeOffset? selectedDate;

    public int Age
    {
        get
        {
            if (SelectedDate is null)
            {
                return 0;
            }

            var today = DateTimeOffset.Now.Date;
            var birthDate = SelectedDate.Value.Date;
            var age = today.Year - birthDate.Year;

            if (birthDate > today.AddYears(-age))
            {
                age--;
            }

            return Math.Max(age, 0);
        }
    }

    public ObservableCollection<string> Languages { get; } = new()
    {
        "C#",
        "Java",
        "Python",
        "JavaScript",
        "Kotlin",
        "C++"
    };

    [ObservableProperty]
    private string? selectedLanguage = "C#";

    [ObservableProperty]
    private double rectangleOpacity = 0.5;

    [ObservableProperty]
    private bool isSwitchEnabled;
}
