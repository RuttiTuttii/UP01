using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using HelloApp.Services;

namespace HelloApp.ViewModels;

public partial class MainWindowViewModel : ViewModelBase
{
    public static NavigationService Navigation { get; } = new();

    [ObservableProperty]
    private ViewModelBase currentPage = null!;

    public MainWindowViewModel()
    {
        Navigation.CurrentPageChanged += page => CurrentPage = page;
        ShowHome();
    }

    [RelayCommand]
    private void ShowHome()
    {
        Navigation.NavigateTo(new HomeViewModel());
    }

    [RelayCommand]
    private void ShowContainers()
    {
        Navigation.NavigateTo(new ContainersViewModel());
    }

    [RelayCommand]
    private void ShowControls()
    {
        Navigation.NavigateTo(new ControlsViewModel());
    }

    [RelayCommand]
    private void ShowRegistration()
    {
        Navigation.NavigateTo(new RegistrationViewModel(), vm =>
        {
            vm.Header = "Регистрация пользователя";
        });
    }

    [RelayCommand]
    private void ShowAuthorization()
    {
        Navigation.NavigateTo(new AuthorizationViewModel());
    }

    [RelayCommand]
    private void GoBack()
    {
        Navigation.GoBack();
    }
}
