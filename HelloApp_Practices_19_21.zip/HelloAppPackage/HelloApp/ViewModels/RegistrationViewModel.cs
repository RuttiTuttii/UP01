using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace HelloApp.ViewModels;

public partial class RegistrationViewModel : ViewModelBase
{
    public UserCreditionals User { get; } = new();

    [ObservableProperty]
    private string header = "Регистрация";

    [ObservableProperty]
    private string validationResult = "Заполните форму и нажмите Проверить.";

    [RelayCommand]
    private void Validate()
    {
        User.ValidateAll();
        ValidationResult = User.HasErrors ? User.ErrorSummary : "Все поля заполнены корректно.";
    }
}
