using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace HelloApp.ViewModels;

public partial class UserCreditionals : ObservableValidator
{
    [ObservableProperty]
    [Required(ErrorMessage = "Логин обязателен")]
    [RegularExpression(@"^[A-Za-z0-9_]{3,20}$", ErrorMessage = "Логин: 3-20 символов, латинские буквы, цифры и _")]
    [NotifyDataErrorInfo]
    private string? name;

    [ObservableProperty]
    [Required(ErrorMessage = "Пароль обязателен")]
    [MinLength(8, ErrorMessage = "Пароль должен быть не короче 8 символов")]
    [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{8,}$", ErrorMessage = "Пароль должен содержать верхний и нижний регистр и спецсимвол")]
    [NotifyDataErrorInfo]
    private string? password;

    [ObservableProperty]
    [Required(ErrorMessage = "Подтверждение пароля обязательно")]
    [Compare(nameof(Password), ErrorMessage = "Пароли должны совпадать")]
    [NotifyDataErrorInfo]
    private string? confirmPassword;

    [ObservableProperty]
    [Required(ErrorMessage = "Email обязателен")]
    [EmailAddress(ErrorMessage = "Введите корректный email")]
    [NotifyDataErrorInfo]
    private string? email;

    [ObservableProperty]
    [Required(ErrorMessage = "Телефон обязателен")]
    [RegularExpression(@"^\+?[0-9\s\-\(\)]{7,20}$", ErrorMessage = "Введите корректный номер телефона")]
    [NotifyDataErrorInfo]
    private string? phone;

    public string ErrorSummary => HasErrors
        ? string.Join("
", GetErrors().Select(error => error.ErrorMessage))
        : "Ошибок нет";

    partial void OnPasswordChanged(string? value)
    {
        ValidateProperty(ConfirmPassword, nameof(ConfirmPassword));
        OnPropertyChanged(nameof(ErrorSummary));
    }

    partial void OnNameChanged(string? value) => OnPropertyChanged(nameof(ErrorSummary));
    partial void OnConfirmPasswordChanged(string? value) => OnPropertyChanged(nameof(ErrorSummary));
    partial void OnEmailChanged(string? value) => OnPropertyChanged(nameof(ErrorSummary));
    partial void OnPhoneChanged(string? value) => OnPropertyChanged(nameof(ErrorSummary));
}
