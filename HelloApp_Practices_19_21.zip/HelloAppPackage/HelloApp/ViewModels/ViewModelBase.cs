using CommunityToolkit.Mvvm.ComponentModel;

namespace HelloApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
