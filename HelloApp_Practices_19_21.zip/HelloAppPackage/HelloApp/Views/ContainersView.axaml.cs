using Avalonia.Controls;

namespace HelloApp.Views;

public partial class ContainersView : UserControl
{
    public ContainersView()
    {
        InitializeComponent();
    }
}
