using Avalonia.Controls;

namespace HelloApp.Views;

public partial class ControlsView : UserControl
{
    public ControlsView()
    {
        InitializeComponent();
    }
}
