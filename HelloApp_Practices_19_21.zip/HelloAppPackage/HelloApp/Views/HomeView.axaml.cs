using Avalonia.Controls;
using HelloApp.ViewModels;

namespace HelloApp.Views;

public partial class HomeView : UserControl
{
    public HomeView()
    {
        InitializeComponent();

        // Строка из задания 5.3.6. При работе через ViewLocator этот DataContext
        // будет заменен объектом HomeViewModel из навигационного стека.
        DataContext ??= new HomeViewModel();
    }
}
