using Avalonia.Controls;

namespace HelloApp.Views;

public partial class RegistrationView : UserControl
{
    public RegistrationView()
    {
        InitializeComponent();
    }
}
