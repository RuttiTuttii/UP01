# HelloApp — практические работы №19–21

Один проект Avalonia UI с реализацией заданий:

- Практическая №19: HomeView, привязки, команда ChangeText, контейнеры DockPanel/Grid/StackPanel.
- Практическая №20: элементы ввода/вывода, CalendarDatePicker, ComboBox, Slider, ToggleSwitch, валидация регистрации.
- Практическая №21: ViewLocator, страничная навигация через ContentControl, NavigationService со стеком и GoBack.

## Как запустить

1. Установить .NET 8 SDK или новее.
2. Открыть `HelloApp.sln` в Visual Studio / Rider / VS Code.
3. Восстановить пакеты:

```bash
dotnet restore
```

4. Запустить проект:

```bash
dotnet run --project HelloApp/HelloApp.csproj
```

## Использованные пакеты

- Avalonia 12.0.1
- Avalonia.Desktop 12.0.1
- Avalonia.Themes.Fluent 12.0.1
- Avalonia.Fonts.Inter 12.0.1
- CommunityToolkit.Mvvm 8.4.2

## Структура

```text
HelloApp/
  Assets/
  Services/NavigationService.cs
  ViewModels/
  Views/
  App.axaml
  ViewLocator.cs
Reports/
  Report_Practice_19.docx
  Report_Practice_20.docx
  Report_Practice_21.docx
```

> Примечание: в этой среде не установлен `dotnet`, поэтому сборка локально не выполнялась. Исходники подготовлены по структуре обычного Avalonia MVVM-проекта.
