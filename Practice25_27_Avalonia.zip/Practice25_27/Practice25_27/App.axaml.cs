using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Practice25_27.Data;
using Practice25_27.Services;
using Practice25_27.ViewModels;
using Practice25_27.Views;

namespace Practice25_27;

public partial class App : Application
{
    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var dbContext = new AppDbContext();
            var userService = new UserService(dbContext);
            var weatherService = new WeatherService();

            desktop.MainWindow = new MainWindow
            {
                DataContext = new MainWindowViewModel(
                    new UserViewModel(userService),
                    new WeatherViewModel(weatherService))
            };
        }

        base.OnFrameworkInitializationCompleted();
    }
}
