using System;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Practice25_27.Models;

namespace Practice25_27.Data;

public class AppDbContext : DbContext
{
    public AppDbContext()
    {
        Database.EnsureCreated();
    }

    public DbSet<User> Users => Set<User>();

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        var dbPath = GetDatabasePath("app.db");
        optionsBuilder.UseSqlite($"Data Source={dbPath}");
    }

    private static string GetDatabasePath(string fileName)
    {
        var folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Practice25_27");

        Directory.CreateDirectory(folder);
        return Path.Combine(folder, fileName);
    }
}
