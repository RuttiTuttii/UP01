using System;
using System.Net.Http;
using System.Threading.Tasks;
using Avalonia.Media.Imaging;

namespace Practice25_27.Helpers;

public static class ImageHelper
{
    private static readonly HttpClient HttpClient = new();

    public static async Task<Bitmap?> LoadFromWeb(string url)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            return null;
        }

        try
        {
            await using var stream = await HttpClient.GetStreamAsync(url);
            return new Bitmap(stream);
        }
        catch
        {
            return null;
        }
    }
}
