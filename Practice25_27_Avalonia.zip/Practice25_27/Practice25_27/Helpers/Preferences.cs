using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Practice25_27.Helpers;

public static class Preferences
{
    private static readonly SemaphoreSlim FileLock = new(1, 1);
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    private static string PreferencesPath
    {
        get
        {
            var folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Practice25_27");

            Directory.CreateDirectory(folder);
            return Path.Combine(folder, "preferences.json");
        }
    }

    public static async Task Save<T>(string key, T data)
    {
        await FileLock.WaitAsync();
        try
        {
            var storage = await ReadStorageAsync();
            storage[key] = JsonSerializer.SerializeToElement(data, JsonOptions);

            await File.WriteAllTextAsync(
                PreferencesPath,
                JsonSerializer.Serialize(storage, JsonOptions));
        }
        finally
        {
            FileLock.Release();
        }
    }

    public static async Task<T> Load<T>(string key, T defaultValue)
    {
        await FileLock.WaitAsync();
        try
        {
            var storage = await ReadStorageAsync();
            if (storage.TryGetValue(key, out var value))
            {
                var result = value.Deserialize<T>();
                if (result is not null)
                {
                    return result;
                }
            }

            return defaultValue;
        }
        finally
        {
            FileLock.Release();
        }
    }

    private static async Task<Dictionary<string, JsonElement>> ReadStorageAsync()
    {
        if (!File.Exists(PreferencesPath))
        {
            return new Dictionary<string, JsonElement>();
        }

        var json = await File.ReadAllTextAsync(PreferencesPath);
        if (string.IsNullOrWhiteSpace(json))
        {
            return new Dictionary<string, JsonElement>();
        }

        return JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(json)
               ?? new Dictionary<string, JsonElement>();
    }
}
