namespace Practice25_27.Models;

public class CitySearchResult
{
    public string Name { get; set; } = string.Empty;
    public string? LocalName { get; set; }
    public string? State { get; set; }
    public string Country { get; set; } = string.Empty;
    public double Latitude { get; set; }
    public double Longitude { get; set; }

    public string DisplayName
    {
        get
        {
            var city = string.IsNullOrWhiteSpace(LocalName) ? Name : LocalName;
            var statePart = string.IsNullOrWhiteSpace(State) ? string.Empty : $", {State}";
            var countryPart = string.IsNullOrWhiteSpace(Country) ? string.Empty : $", {Country}";
            return $"{city}{statePart}{countryPart} ({Latitude:0.####}, {Longitude:0.####})";
        }
    }
}
