using System;
using System.Threading.Tasks;
using Avalonia.Media.Imaging;
using Practice25_27.Helpers;

namespace Practice25_27.Models;

public class WeatherCardModel
{
    private Task<Bitmap?>? _imageTask;

    public string CityName { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string Description { get; set; } = string.Empty;
    public double Temperature { get; set; }
    public double FeelsLike { get; set; }
    public int PressureHpa { get; set; }
    public int Humidity { get; set; }
    public double WindSpeed { get; set; }
    public int WindDegrees { get; set; }
    public int Cloudiness { get; set; }
    public double? RainOneHour { get; set; }
    public double? SnowOneHour { get; set; }
    public string IconCode { get; set; } = "01d";
    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    public string TitleText => string.IsNullOrWhiteSpace(Country) ? CityName : $"{CityName}, {Country}";
    public string DescriptionText => string.IsNullOrWhiteSpace(Description) ? "Описание отсутствует" : ToCapitalized(Description);
    public string TemperatureText => $"Температура: {Temperature:0.#} °C";
    public string FeelsLikeText => $"Ощущается как: {FeelsLike:0.#} °C";
    public string PressureText => $"Давление: {PressureHpaToMmHg(PressureHpa)} мм рт. ст. ({PressureHpa} гПа)";
    public string HumidityText => $"Влажность: {Humidity}%";
    public string WindText => $"Ветер: {GetWindDirection(WindDegrees)}, {WindSpeed:0.#} м/с";
    public string CloudsText => $"Облачность: {Cloudiness}%";
    public string RainText => RainOneHour is null ? "Дождь: нет" : $"Дождь: {RainOneHour:0.#} мм/ч";
    public string SnowText => SnowOneHour is null ? "Снег: нет" : $"Снег: {SnowOneHour:0.#} мм/ч";
    public string UpdatedAtText => $"Обновлено: {UpdatedAt:HH:mm}";
    public string IconUrl => $"https://openweathermap.org/img/wn/{IconCode}@2x.png";
    public Task<Bitmap?> Image => _imageTask ??= ImageHelper.LoadFromWeb(IconUrl);

    public SavedCity ToSavedCity()
    {
        return new SavedCity
        {
            Name = CityName,
            Country = Country,
            Latitude = Latitude,
            Longitude = Longitude
        };
    }

    private static int PressureHpaToMmHg(int pressureHpa)
    {
        return (int)Math.Round(pressureHpa * 0.750062);
    }

    private static string GetWindDirection(int degrees)
    {
        var directions = new[]
        {
            "северный",
            "северо-восточный",
            "восточный",
            "юго-восточный",
            "южный",
            "юго-западный",
            "западный",
            "северо-западный"
        };

        var index = (int)Math.Round(((degrees % 360) / 45.0)) % 8;
        return directions[index];
    }

    private static string ToCapitalized(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return string.Empty;
        }

        return char.ToUpper(value[0]) + value[1..];
    }
}
