using Microsoft.EntityFrameworkCore;
using Practice25_27.Data;
using Practice25_27.Models;

namespace Practice25_27.Services;

public class UserService
{
    private readonly AppDbContext _dbContext;

    public UserService(AppDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<List<User>> GetAllAsync()
    {
        return await _dbContext.Users
            .AsNoTracking()
            .OrderBy(user => user.Id)
            .ToListAsync();
    }

    public async Task<User> AddAsync(string login, string password)
    {
        var user = new User
        {
            Login = login.Trim(),
            Password = password.Trim()
        };

        _dbContext.Users.Add(user);
        await _dbContext.SaveChangesAsync();
        return user;
    }

    public async Task UpdateAsync(int id, string login, string password)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(item => item.Id == id);
        if (user is null)
        {
            return;
        }

        user.Login = login.Trim();
        user.Password = password.Trim();
        await _dbContext.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(item => item.Id == id);
        if (user is null)
        {
            return;
        }

        _dbContext.Users.Remove(user);
        await _dbContext.SaveChangesAsync();
    }
}
