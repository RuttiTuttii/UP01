using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Practice25_27.Models;

namespace Practice25_27.Services;

public class WeatherService
{
    private readonly HttpClient _httpClient = new();
    private readonly string _apiKey;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public WeatherService(string? apiKey = null)
    {
        _apiKey = string.IsNullOrWhiteSpace(apiKey) ? LoadApiKeyFromSettings() : apiKey.Trim();
    }

    public async Task<IReadOnlyList<CitySearchResult>> SearchCitiesAsync(string cityName)
    {
        EnsureApiKey();

        if (string.IsNullOrWhiteSpace(cityName))
        {
            return Array.Empty<CitySearchResult>();
        }

        var query = Uri.EscapeDataString(cityName.Trim());
        var url = $"https://api.openweathermap.org/geo/1.0/direct?q={query}&limit=10&appid={_apiKey}";
        var cities = await GetFromJsonAsync<List<GeocodingItem>>(url) ?? new List<GeocodingItem>();

        return cities.Select(city => new CitySearchResult
            {
                Name = city.Name ?? string.Empty,
                LocalName = city.LocalNames?.TryGetValue("ru", out var russianName) == true ? russianName : city.Name,
                State = city.State,
                Country = city.Country ?? string.Empty,
                Latitude = city.Latitude,
                Longitude = city.Longitude
            })
            .ToList();
    }

    public async Task<WeatherCardModel> GetCurrentByCityNameAsync(string cityName)
    {
        EnsureApiKey();

        if (string.IsNullOrWhiteSpace(cityName))
        {
            throw new ArgumentException("Введите название города.", nameof(cityName));
        }

        var query = Uri.EscapeDataString(cityName.Trim());
        var url = $"https://api.openweathermap.org/data/2.5/weather?q={query}&appid={_apiKey}&units=metric&lang=ru";
        var response = await GetFromJsonAsync<CurrentWeatherResponse>(url);
        return MapToWeatherCard(response);
    }

    public async Task<WeatherCardModel> GetCurrentByCoordinatesAsync(double latitude, double longitude)
    {
        EnsureApiKey();

        var lat = latitude.ToString(CultureInfo.InvariantCulture);
        var lon = longitude.ToString(CultureInfo.InvariantCulture);
        var url = $"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={_apiKey}&units=metric&lang=ru";
        var response = await GetFromJsonAsync<CurrentWeatherResponse>(url);
        return MapToWeatherCard(response);
    }

    private async Task<T?> GetFromJsonAsync<T>(string url)
    {
        using var response = await _httpClient.GetAsync(url);
        var json = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var message = TryReadApiMessage(json);
            throw new InvalidOperationException(string.IsNullOrWhiteSpace(message)
                ? $"API вернул ошибку: {(int)response.StatusCode} {response.ReasonPhrase}"
                : $"API вернул ошибку: {message}");
        }

        return JsonSerializer.Deserialize<T>(json, JsonOptions);
    }

    private static WeatherCardModel MapToWeatherCard(CurrentWeatherResponse? response)
    {
        if (response is null)
        {
            throw new InvalidOperationException("Не удалось прочитать ответ API.");
        }

        var weather = response.Weather?.FirstOrDefault();

        return new WeatherCardModel
        {
            CityName = response.Name ?? "Без названия",
            Country = response.Sys?.Country ?? string.Empty,
            Latitude = response.Coord?.Latitude ?? 0,
            Longitude = response.Coord?.Longitude ?? 0,
            Description = weather?.Description ?? string.Empty,
            IconCode = string.IsNullOrWhiteSpace(weather?.Icon) ? "01d" : weather.Icon,
            Temperature = response.Main?.Temperature ?? 0,
            FeelsLike = response.Main?.FeelsLike ?? 0,
            PressureHpa = response.Main?.Pressure ?? 0,
            Humidity = response.Main?.Humidity ?? 0,
            WindSpeed = response.Wind?.Speed ?? 0,
            WindDegrees = response.Wind?.Degrees ?? 0,
            Cloudiness = response.Clouds?.All ?? 0,
            RainOneHour = response.Rain?.OneHour,
            SnowOneHour = response.Snow?.OneHour,
            UpdatedAt = DateTime.Now
        };
    }

    private static string LoadApiKeyFromSettings()
    {
        var possiblePaths = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "appsettings.json"),
            Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json")
        };

        foreach (var path in possiblePaths)
        {
            if (!File.Exists(path))
            {
                continue;
            }

            using var stream = File.OpenRead(path);
            using var document = JsonDocument.Parse(stream);
            var root = document.RootElement;

            if (root.TryGetProperty("ApiKey", out var apiKeyElement))
            {
                var apiKey = apiKeyElement.GetString();
                if (!IsPlaceholderOrEmpty(apiKey))
                {
                    return apiKey!.Trim();
                }
            }

            if (root.TryGetProperty("OpenWeather", out var openWeatherElement)
                && openWeatherElement.TryGetProperty("ApiKey", out var nestedApiKeyElement))
            {
                var apiKey = nestedApiKeyElement.GetString();
                if (!IsPlaceholderOrEmpty(apiKey))
                {
                    return apiKey!.Trim();
                }
            }
        }

        return string.Empty;
    }

    private void EnsureApiKey()
    {
        if (IsPlaceholderOrEmpty(_apiKey))
        {
            throw new InvalidOperationException("Укажите OpenWeather API-ключ в файле appsettings.json.");
        }
    }

    private static bool IsPlaceholderOrEmpty(string? value)
    {
        return string.IsNullOrWhiteSpace(value)
               || value.Contains("PASTE_OPENWEATHER_API_KEY_HERE", StringComparison.OrdinalIgnoreCase)
               || value.Contains("ВАШ_КЛЮЧ", StringComparison.OrdinalIgnoreCase);
    }

    private static string? TryReadApiMessage(string json)
    {
        try
        {
            using var document = JsonDocument.Parse(json);
            if (document.RootElement.TryGetProperty("message", out var messageElement))
            {
                return messageElement.GetString();
            }
        }
        catch
        {
            return null;
        }

        return null;
    }

    private class GeocodingItem
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("local_names")]
        public Dictionary<string, string>? LocalNames { get; set; }

        [JsonPropertyName("lat")]
        public double Latitude { get; set; }

        [JsonPropertyName("lon")]
        public double Longitude { get; set; }

        [JsonPropertyName("country")]
        public string? Country { get; set; }

        [JsonPropertyName("state")]
        public string? State { get; set; }
    }

    private class CurrentWeatherResponse
    {
        [JsonPropertyName("coord")]
        public CoordInfo? Coord { get; set; }

        [JsonPropertyName("weather")]
        public List<WeatherInfo>? Weather { get; set; }

        [JsonPropertyName("main")]
        public MainInfo? Main { get; set; }

        [JsonPropertyName("wind")]
        public WindInfo? Wind { get; set; }

        [JsonPropertyName("clouds")]
        public CloudsInfo? Clouds { get; set; }

        [JsonPropertyName("rain")]
        public PrecipitationInfo? Rain { get; set; }

        [JsonPropertyName("snow")]
        public PrecipitationInfo? Snow { get; set; }

        [JsonPropertyName("sys")]
        public SysInfo? Sys { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }
    }

    private class CoordInfo
    {
        [JsonPropertyName("lat")]
        public double Latitude { get; set; }

        [JsonPropertyName("lon")]
        public double Longitude { get; set; }
    }

    private class WeatherInfo
    {
        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("icon")]
        public string? Icon { get; set; }
    }

    private class MainInfo
    {
        [JsonPropertyName("temp")]
        public double Temperature { get; set; }

        [JsonPropertyName("feels_like")]
        public double FeelsLike { get; set; }

        [JsonPropertyName("pressure")]
        public int Pressure { get; set; }

        [JsonPropertyName("humidity")]
        public int Humidity { get; set; }
    }

    private class WindInfo
    {
        [JsonPropertyName("speed")]
        public double Speed { get; set; }

        [JsonPropertyName("deg")]
        public int Degrees { get; set; }
    }

    private class CloudsInfo
    {
        [JsonPropertyName("all")]
        public int All { get; set; }
    }

    private class PrecipitationInfo
    {
        [JsonPropertyName("1h")]
        public double? OneHour { get; set; }

        [JsonPropertyName("3h")]
        public double? ThreeHours { get; set; }
    }

    private class SysInfo
    {
        [JsonPropertyName("country")]
        public string? Country { get; set; }
    }
}
