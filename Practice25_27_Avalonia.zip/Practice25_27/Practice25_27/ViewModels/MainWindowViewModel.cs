namespace Practice25_27.ViewModels;

public class MainWindowViewModel : ViewModelBase
{
    public MainWindowViewModel(UserViewModel userViewModel, WeatherViewModel weatherViewModel)
    {
        UserViewModel = userViewModel;
        WeatherViewModel = weatherViewModel;
    }

    public UserViewModel UserViewModel { get; }
    public WeatherViewModel WeatherViewModel { get; }
}
