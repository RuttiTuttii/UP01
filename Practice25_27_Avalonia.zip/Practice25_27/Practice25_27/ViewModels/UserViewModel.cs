using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;
using Practice25_27.Models;
using Practice25_27.Services;

namespace Practice25_27.ViewModels;

public class UserViewModel : ViewModelBase
{
    private readonly UserService _userService;
    private string _login = string.Empty;
    private string _password = string.Empty;
    private int? _editingUserId;
    private string _statusMessage = string.Empty;

    public UserViewModel(UserService userService)
    {
        _userService = userService;

        AddUserCommand = new AsyncRelayCommand(AddUserAsync, CanAddUser);
        SaveUserCommand = new AsyncRelayCommand(SaveUserAsync, CanSaveUser);
        CancelEditCommand = new RelayCommand(CancelEdit);
        EditUserCommand = new RelayCommand<User?>(EditUser);
        DeleteUserCommand = new AsyncRelayCommand<User?>(DeleteUserAsync);

        _ = LoadUsersAsync();
    }

    public ObservableCollection<User> Users { get; } = new();

    public string Login
    {
        get => _login;
        set
        {
            if (SetProperty(ref _login, value))
            {
                NotifyInputCommands();
            }
        }
    }

    public string Password
    {
        get => _password;
        set
        {
            if (SetProperty(ref _password, value))
            {
                NotifyInputCommands();
            }
        }
    }

    public bool IsEditing => _editingUserId is not null;
    public bool IsCreating => !IsEditing;

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetProperty(ref _statusMessage, value);
    }

    public IAsyncRelayCommand AddUserCommand { get; }
    public IAsyncRelayCommand SaveUserCommand { get; }
    public IRelayCommand CancelEditCommand { get; }
    public IRelayCommand<User?> EditUserCommand { get; }
    public IAsyncRelayCommand<User?> DeleteUserCommand { get; }

    private async Task LoadUsersAsync()
    {
        Users.Clear();
        var users = await _userService.GetAllAsync();
        foreach (var user in users)
        {
            Users.Add(user);
        }
    }

    private bool CanAddUser()
    {
        return IsCreating && HasInputData();
    }

    private bool CanSaveUser()
    {
        return IsEditing && HasInputData();
    }

    private bool HasInputData()
    {
        return !string.IsNullOrWhiteSpace(Login) && !string.IsNullOrWhiteSpace(Password);
    }

    private async Task AddUserAsync()
    {
        await _userService.AddAsync(Login, Password);
        ClearForm();
        await LoadUsersAsync();
        StatusMessage = "Пользователь добавлен в базу данных.";
    }

    private void EditUser(User? user)
    {
        if (user is null)
        {
            return;
        }

        _editingUserId = user.Id;
        Login = user.Login;
        Password = user.Password;
        StatusMessage = $"Редактирование пользователя #{user.Id}.";
        NotifyEditingStateChanged();
    }

    private async Task SaveUserAsync()
    {
        if (_editingUserId is null)
        {
            return;
        }

        await _userService.UpdateAsync(_editingUserId.Value, Login, Password);
        ClearForm();
        await LoadUsersAsync();
        StatusMessage = "Изменения сохранены в базе данных.";
    }

    private void CancelEdit()
    {
        ClearForm();
        StatusMessage = "Редактирование отменено.";
    }

    private async Task DeleteUserAsync(User? user)
    {
        if (user is null)
        {
            return;
        }

        await _userService.DeleteAsync(user.Id);
        if (_editingUserId == user.Id)
        {
            ClearForm();
        }

        await LoadUsersAsync();
        StatusMessage = "Пользователь удален из базы данных.";
    }

    private void ClearForm()
    {
        _editingUserId = null;
        Login = string.Empty;
        Password = string.Empty;
        NotifyEditingStateChanged();
    }

    private void NotifyInputCommands()
    {
        AddUserCommand.NotifyCanExecuteChanged();
        SaveUserCommand.NotifyCanExecuteChanged();
    }

    private void NotifyEditingStateChanged()
    {
        OnPropertyChanged(nameof(IsEditing));
        OnPropertyChanged(nameof(IsCreating));
        NotifyInputCommands();
    }
}
