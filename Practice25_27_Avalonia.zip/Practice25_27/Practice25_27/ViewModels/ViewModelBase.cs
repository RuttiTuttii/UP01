using CommunityToolkit.Mvvm.ComponentModel;

namespace Practice25_27.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
