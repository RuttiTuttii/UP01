using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.Input;
using Practice25_27.Helpers;
using Practice25_27.Models;
using Practice25_27.Services;

namespace Practice25_27.ViewModels;

public class WeatherViewModel : ViewModelBase
{
    private const string SavedCitiesKey = "weather_cards_cities";

    private readonly WeatherService _weatherService;
    private string _searchText = string.Empty;
    private CitySearchResult? _selectedCity;
    private string _statusMessage = string.Empty;
    private bool _isBusy;
    private TaskNotifier? _initializationTask;

    public WeatherViewModel(WeatherService weatherService)
    {
        _weatherService = weatherService;

        SearchCommand = new AsyncRelayCommand(SearchCitiesAsync, CanSearchCities);
        AddSelectedCityCommand = new AsyncRelayCommand(AddSelectedCityAsync, CanAddSelectedCity);
        RefreshCardCommand = new AsyncRelayCommand<WeatherCardModel?>(RefreshCardAsync);
        DeleteCardCommand = new AsyncRelayCommand<WeatherCardModel?>(DeleteCardAsync);

        InitializationTask = InitializeAsync();
    }

    public ObservableCollection<CitySearchResult> Cities { get; } = new();
    public ObservableCollection<WeatherCardModel> Forecasts { get; } = new();

    public Task? InitializationTask
    {
        get => _initializationTask;
        private set => SetPropertyAndNotifyOnCompletion(ref _initializationTask, value);
    }

    public string SearchText
    {
        get => _searchText;
        set
        {
            if (SetProperty(ref _searchText, value))
            {
                SearchCommand.NotifyCanExecuteChanged();
            }
        }
    }

    public CitySearchResult? SelectedCity
    {
        get => _selectedCity;
        set
        {
            if (SetProperty(ref _selectedCity, value))
            {
                AddSelectedCityCommand.NotifyCanExecuteChanged();
            }
        }
    }

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetProperty(ref _statusMessage, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                SearchCommand.NotifyCanExecuteChanged();
                AddSelectedCityCommand.NotifyCanExecuteChanged();
            }
        }
    }

    public IAsyncRelayCommand SearchCommand { get; }
    public IAsyncRelayCommand AddSelectedCityCommand { get; }
    public IAsyncRelayCommand<WeatherCardModel?> RefreshCardCommand { get; }
    public IAsyncRelayCommand<WeatherCardModel?> DeleteCardCommand { get; }

    private async Task InitializeAsync()
    {
        var savedCities = await Preferences.Load(SavedCitiesKey, new List<SavedCity>());
        if (savedCities.Count == 0)
        {
            StatusMessage = "Введите город и нажмите «Поиск».";
            return;
        }

        IsBusy = true;
        try
        {
            foreach (var city in savedCities)
            {
                try
                {
                    var weather = await _weatherService.GetCurrentByCoordinatesAsync(city.Latitude, city.Longitude);
                    Forecasts.Add(weather);
                }
                catch
                {
                    Forecasts.Add(new WeatherCardModel
                    {
                        CityName = city.Name,
                        Country = city.Country,
                        Latitude = city.Latitude,
                        Longitude = city.Longitude,
                        Description = "Не удалось обновить данные",
                        UpdatedAt = DateTime.Now
                    });
                }
            }

            StatusMessage = "Сохраненные города загружены.";
        }
        finally
        {
            IsBusy = false;
        }
    }

    private bool CanSearchCities()
    {
        return !IsBusy && !string.IsNullOrWhiteSpace(SearchText);
    }

    private bool CanAddSelectedCity()
    {
        return !IsBusy && SelectedCity is not null;
    }

    private async Task SearchCitiesAsync()
    {
        IsBusy = true;
        StatusMessage = "Ищу города...";
        Cities.Clear();
        SelectedCity = null;

        try
        {
            var cities = await _weatherService.SearchCitiesAsync(SearchText);
            foreach (var city in cities)
            {
                Cities.Add(city);
            }

            StatusMessage = Cities.Count == 0
                ? "Города не найдены. Проверьте название."
                : "Выберите город из списка.";
        }
        catch (Exception ex)
        {
            StatusMessage = ex.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task AddSelectedCityAsync()
    {
        if (SelectedCity is null)
        {
            return;
        }

        if (Forecasts.Any(item => IsSameCoordinates(item.Latitude, item.Longitude, SelectedCity.Latitude, SelectedCity.Longitude)))
        {
            StatusMessage = "Этот город уже есть в списке.";
            return;
        }

        IsBusy = true;
        StatusMessage = "Загружаю погоду...";

        try
        {
            var weather = await _weatherService.GetCurrentByCoordinatesAsync(SelectedCity.Latitude, SelectedCity.Longitude);
            Forecasts.Add(weather);
            await SaveForecastCitiesAsync();
            StatusMessage = "Карточка добавлена и сохранена.";
        }
        catch (Exception ex)
        {
            StatusMessage = ex.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task RefreshCardAsync(WeatherCardModel? card)
    {
        if (card is null)
        {
            return;
        }

        var index = Forecasts.IndexOf(card);
        if (index < 0)
        {
            return;
        }

        try
        {
            var updatedCard = await _weatherService.GetCurrentByCoordinatesAsync(card.Latitude, card.Longitude);
            Forecasts[index] = updatedCard;
            await SaveForecastCitiesAsync();
            StatusMessage = $"Карточка «{updatedCard.TitleText}» обновлена.";
        }
        catch (Exception ex)
        {
            StatusMessage = ex.Message;
        }
    }

    private async Task DeleteCardAsync(WeatherCardModel? card)
    {
        if (card is null)
        {
            return;
        }

        Forecasts.Remove(card);
        await SaveForecastCitiesAsync();
        StatusMessage = "Карточка удалена из списка.";
    }

    private async Task SaveForecastCitiesAsync()
    {
        var savedCities = Forecasts
            .Select(item => item.ToSavedCity())
            .ToList();

        await Preferences.Save(SavedCitiesKey, savedCities);
    }

    private static bool IsSameCoordinates(double lat1, double lon1, double lat2, double lon2)
    {
        return Math.Abs(lat1 - lat2) < 0.0001 && Math.Abs(lon1 - lon2) < 0.0001;
    }
}
