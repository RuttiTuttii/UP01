using Avalonia.Controls;

namespace Practice25_27.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
