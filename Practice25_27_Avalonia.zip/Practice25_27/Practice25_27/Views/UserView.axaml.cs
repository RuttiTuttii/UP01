using Avalonia.Controls;

namespace Practice25_27.Views;

public partial class UserView : UserControl
{
    public UserView()
    {
        InitializeComponent();
    }
}
