using Avalonia.Controls;

namespace Practice25_27.Views;

public partial class WeatherView : UserControl
{
    public WeatherView()
    {
        InitializeComponent();
    }
}
